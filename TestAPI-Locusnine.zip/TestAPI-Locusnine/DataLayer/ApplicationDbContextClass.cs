﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using TestAPI.Models;

namespace TestAPI.Models
{
    public class ApplicationDbContextClass: DbContext
    {
        public ApplicationDbContextClass(DbContextOptions<ApplicationDbContextClass> options):base(options)
        {

        }

        public DbSet<User> TestUsers2 { get; set; }
    }
}
