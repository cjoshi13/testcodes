﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TestAPI.Models;

namespace TestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContextClass _context;

        public UserController(ApplicationDbContextClass context)
        {
            _context = context;
        }

        // GET: api/User
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetTestUsers2()
        {
            return await _context.TestUsers2.ToListAsync();
        }

        // GET: api/User/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _context.TestUsers2.FindAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(User euc)
        {
            if (ModelState.IsValid)
            {
                string val = euc.Email;
                if (val.Contains("/"))
                {
                    string rpc = val.Replace("/", "+1");

                    euc.Email = rpc;
                }

                _context.Update(euc);
                await _context.SaveChangesAsync();
                
            }

            return BadRequest();
        }

       
        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {

            string val = user.Email;
            if (val.Contains("/"))
            {
                string rpc = val.Replace("/", "+1");

                user.Email = rpc;
            }

            _context.TestUsers2.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUser", new { id = user.id }, user);
        }

        // DELETE: api/User/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<User>> DeleteUser(int id)
        {
            var user = await _context.TestUsers2.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.TestUsers2.Remove(user);
            await _context.SaveChangesAsync();

            return user;
        }

        private bool UserExists(int id)
        {
            return _context.TestUsers2.Any(e => e.id == id);
        }
    }
}
