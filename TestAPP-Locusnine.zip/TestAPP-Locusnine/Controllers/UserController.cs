﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using testlocus.Models;
using Microsoft.EntityFrameworkCore;
using System.Windows.Markup;

namespace testlocus.Controllers
{
    public class UserController : Controller
    {

        MyUsers usr = new MyUsers();
        private string values;

        private readonly ApplicationDbContextClass _db;

        public UserController(ApplicationDbContextClass db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var displaydata = _db.TestUsers2.ToList();
            return View(displaydata);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]

        public async Task<IActionResult> Create(MyUsers usr)
        {


            if (ModelState.IsValid)
            {
                string val=usr.Email;
                if (val.Contains("/"))
                {
                    string rpc = val.Replace("/", "+1");

                    usr.Email = rpc;
                }
                

                _db.Add(usr);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(usr);
        
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var getuserdetails = await _db.TestUsers2.FindAsync(id);
            return View(getuserdetails);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(MyUsers euc)
        {
            if (ModelState.IsValid)
            {
                string val = euc.Email;
                if (val.Contains("/"))
                {
                    string rpc = val.Replace("/", "+1");

                    euc.Email = rpc;
                }

                _db.Update(euc);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(euc);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var getuserdetails = await _db.TestUsers2.FindAsync(id);
            return View(getuserdetails);
        }


        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var getuserdetails = await _db.TestUsers2.FindAsync(id);
            return View(getuserdetails);
        }


        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        { 
            var getuserdetails = await _db.TestUsers2.FindAsync(id);
            _db.TestUsers2.Remove(getuserdetails);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }


    }
}
