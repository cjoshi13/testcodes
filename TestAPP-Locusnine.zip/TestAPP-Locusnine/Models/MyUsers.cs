﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace testlocus.Models
{
    public class MyUsers
    {
        [Key]
        public int id { get; set;}

        [Required(ErrorMessage ="Enter user name")]
        [Display(Name="User name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Enter Email")]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; } 
        public string Roletype { get; set; }

      
        public int Mobilenumber { get; set; } 
        public bool Status { get; set; } 
    }
}
